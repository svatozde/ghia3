from ghia.cli import cli

print("Entering __main__ :" + __name__)

cli()